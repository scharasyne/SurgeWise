# SurgeWise: direct barangay forecasting, 80/10/10 evaluation

## Web app release

Deploy the self-contained [production folder](production/README.md) for Python or HTTP inference. It includes the validation-selected random forest, its feature data and a JSON prediction endpoint. The app can request 1–6 weeks ahead from the last supplied observation. The built-in example starts in 2023. Later-year simulations retain the 2022 annual and GP feature snapshot. After an applicable refit, run `python export_production.py` in the training environment to rebuild the release assets from the fitted bundle.

## Running the project

From the project directory, install the dependencies in a Python 3.12 or 3.13 environment. The saved models use the library versions pinned in `requirements.txt`.

```sh
python -m pip install -r requirements.txt
python predict.py --out forecast
python predict.py --updates examples/updates_example.csv --out updated
```

Both commands write six-week forecasts to `outputs/forecasts/`. City updates use the columns `year,week,city_cases` and start at 2023 week 1. Optional `--local-updates` accepts `year,week,barangay_code,cases` for the same weeks. This example forecasts historical 2023 observations.

Run `python evaluate_split.py` to repeat the 80/10/10 evaluation, refit the models, and replace the saved results. To reproduce the GP reconstruction, open the notebook with `python -m jupyterlab notebooks/GP_reference.ipynb` and run its cells in order. It writes the weekly estimates to `data/processed/gp_cases.csv` and the audit and sensitivity tables to `outputs/reconstruction/`. The supplied weekly estimates are ready for forecasting.

## Project layout

| Location | Contents |
| --- | --- |
| `notebooks/` | GP reconstruction and reconciliation notebook |
| `data/raw/` | Original weekly counts, annual totals, environmental workbook, boundaries, and 2023 city observations |
| `data/processed/` | Weekly barangay estimates, neighbor weights, population and geometry features |
| `examples/` | Sample city updates for the prediction command |
| `models/` | Saved estimators, feature-column order, and validation-based selection |
| `outputs/evaluation/` | Target-week split, validation metrics, combined metrics, and weekly backtest |
| `outputs/forecasts/` | Model comparisons, selected barangay forecasts, city totals, and scenario outputs |
| `engine.py` | Shared feature construction, estimators, and forecasting |
| `evaluate_split.py` | Block assignment, training, validation, and testing |
| `predict.py` | Saved-model inference and optional surge scenarios |

## Split and validation
- 2012 supplies prior-year lag information; it is not a supervised target. Of the remaining 520 target weeks (2013–2022), 416 (2013–2020) are training, 52 validation, 52 test. Each target week contains 142 barangay rows before masking missing reported annual totals. This is an exact 80/10/10 split of eligible unique target weeks, not of overlapping supervised rows.
- Randomly assign complete multi-week blocks from 2021 and 2022 (eight disjoint six-week blocks and one four-week block per year) using seed 42. Select eight full and one short block for test, the remainder for validation. Each set has exactly 52 weeks. All barangays of any target week stay together. The training set precedes all validation/test blocks. No target week appears in more than one set within a protocol.
- This is a randomized *late holdout*, not an IID random sample across all years. There is a separate chronological evaluation (2021 validation; 2022 test). The latter is a sensitivity check on the same historical data, not a second independent dataset. Random holdout model selection can use validation blocks later than some test blocks; it is retrospective. Historical observations from earlier test/validation periods may become legal past inputs for later origins; no future target data are used as contemporaneous inputs or to update fitted weights.
- Fit pooled RF, XGB, LightGBM with three fixed configurations each. Also compare an equal mean of original variants, local persistence, seasonal naive, and city persistence with seasonal shares. Select by validation six-week cumulative city MAE (local imputed MAE tie-break), not test scores. Model selection is not repeatedly adjusted to reach desired test accuracy. Full weekly metrics cover 52 weeks, and cumulative/peak metrics use the eight full six-week blocks; short blocks use only four predicted weeks. Training origins are spaced three weeks apart with overlapping forecast targets; this increases training examples but not independent information. Missing annual barangay labels are excluded from training and local error scoring; city error uses observed city totals (including unassigned cases), while bottom-up predictions cover 142 assigned barangays.
- Forecast-time-safe features use only completed-year GP data and prior-year totals, with provisional within-year local estimates based on observed city totals when actual weekly barangay history is missing. Assume completed annual totals are available at year end; publication timing may delay them. The initial 52-week lag is missing for the first origin, handled as NaN, not indexed from the end of the series. GP counts are expected values, not independently observed counts; no GP interval propagation in this model. Historical GP target values use full-year constraints. Test local MAE measures reconstructed patterns, not confirmed weekly local cases.
- After locking candidates and scoring the holdouts, refit ML family winners on all 2013–2022 eligible targets for the historical 2023 forecast. 2023 weeks 1–6 are cross-source UPRI NOAH comparison; no UPRI observations used for that prediction. Updated weeks 7–12 use observed weeks 1–6 as inputs without refitting weights. 2023 has been examined before, so it is not a previously unseen research test. No genuine prospective validation yet.
- Historical features: lagged local and city counts, rolling averages, growth, annual counts/shares, population, area, density, incidence, neighboring burden, seasonality, GP-based seasonality. Weather/settlement excluded. Model predicts fractional nonnegative expected case counts independently for each barangay; city forecasts are sums. Surge parameters in predict.py are assumptions, not predicted outbreak onset. The default inference model is the best ML candidate, not automatically better than baselines.
