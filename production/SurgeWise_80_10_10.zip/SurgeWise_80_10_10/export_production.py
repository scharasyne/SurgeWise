"""Export the selected fitted forest and its 2023 feature inputs for the web app."""

import json
import shutil
from pathlib import Path

import joblib
import numpy as np

import engine

PACKAGE = Path(__file__).resolve().parent / "production" / "surgewise"


def export(bundle):
    selection = bundle["selection"]
    if selection["selected_ml"] != "RF" or selection["train_through"] != 2022:
        raise ValueError("This exporter supports the selected RF trained through 2022.")

    # Store the actual splits and leaf predictions, preserving scikit-learn's
    # float64 thresholds and its learned direction for missing features.
    trees = [estimator.tree_ for estimator in bundle["models"]["RF"].estimators_]
    offsets = np.cumsum([0] + [tree.node_count for tree in trees[:-1]])
    forest = {"roots": offsets}
    for key in ("children_left", "children_right"):
        children = [getattr(tree, key) for tree in trees]
        forest[key] = np.concatenate([
            np.where(nodes == -1, -1, nodes + offset) for nodes, offset in zip(children, offsets)
        ])
    for key in ("feature", "threshold", "missing_go_to_left"):
        forest[key] = np.concatenate([getattr(tree, key) for tree in trees])
    forest["value"] = np.concatenate([tree.value[:, 0, 0] for tree in trees])
    model_dir = PACKAGE / "models"
    model_dir.mkdir(exist_ok=True)
    np.savez_compressed(model_dir / "forest.npz", **forest)

    data_dir = PACKAGE / "data"
    data_dir.mkdir(exist_ok=True)
    shutil.copyfile(engine.PROCESSED / "gp_cases.csv", data_dir / "gp_cases.csv")
    annual, end, past, shares = engine.prior(2023)
    assert end == len(engine.city_cases)
    engine.geography.to_csv(data_dir / "barangays.csv", index=False)
    np.savez_compressed(
        data_dir / "history.npz",
        city=engine.city_cases,
        local=np.where(engine.known, engine.local_cases, np.nan),
        weights=engine.weights, past=past, shares=shares, **annual,
    )
    metadata = dict(
        model=selection["selected_variant"], trained_through=selection["train_through"],
        forecast_year=2023, horizon=engine.HORIZON, columns=bundle["columns"],
        annual_features=list(annual),
    )
    (model_dir / "model.json").write_text(json.dumps(metadata, indent=2) + "\n")


if __name__ == "__main__":
    export(joblib.load(engine.MODELS / "models.joblib"))
