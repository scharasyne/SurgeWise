"""Features, estimators, and bottom-up forecasts for Quezon City's barangays."""

from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd

from production.surgewise.features import HORIZON, WEEKS, feature_blocks

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "data" / "raw"
PROCESSED = ROOT / "data" / "processed"
MODELS = ROOT / "models"
FORECASTS = ROOT / "outputs" / "forecasts"
EVALUATION = ROOT / "outputs" / "evaluation"

FIRST_YEAR = 2012
FAMILIES = ("RF", "XGB", "LGBM")

weekly = pd.read_csv(PROCESSED / "gp_cases.csv")
assigned = weekly.loc[weekly.barangay_code != "UNASSIGNED"]
week_keys = ["year", "source_week"]
geography = (
    assigned[["barangay_code", "barangay"]].drop_duplicates()
    .sort_values("barangay_code").reset_index(drop=True)
)
codes = geography.barangay_code.to_numpy()
barangay_count = len(codes)


def weekly_matrix(column):
    """Align a weekly field to the same barangay order used by the estimators."""
    return assigned.pivot(index=week_keys, columns="barangay_code", values=column)[codes]


local_cases = weekly_matrix("gp_expected_cases").to_numpy()
known = weekly_matrix("reported_annual_barangay_cases").notna().to_numpy()
city_cases = weekly.groupby(week_keys).observed_city_week_cases.first().to_numpy(float)
annual_cases = pd.read_csv(RAW / "annual_cases.csv").set_index("ADM4_PCODE").loc[codes]
population = pd.read_csv(PROCESSED / "population_geometry.csv").set_index("barangay_code").loc[codes]
area = population.polygon_area_km2.to_numpy(float)
edges = pd.read_csv(PROCESSED / "adjacency.csv")
weights = (
    edges.pivot(index="barangay_code", columns="neighbor_code", values="weight")
    .reindex(index=codes, columns=codes).fillna(0).to_numpy()
)
external_cases = pd.read_csv(RAW / "upri_2023.csv").set_index("week").actual.sort_index()

if local_cases.shape != (572, 142) or not np.allclose(
    weekly.groupby(week_keys).gp_expected_cases.sum(), city_cases
):
    raise ValueError("Expected 572 weeks and 142 barangays reconciled to city totals")
if not np.allclose(weights.sum(axis=1), 1):
    raise ValueError("Neighbor weights must sum to one per barangay")


def normalize(values):
    """Return nonnegative shares, using equal shares for a zero total."""
    values = np.maximum(np.asarray(values, float), 0)
    totals = values.sum(axis=-1, keepdims=True)
    uniform = np.full_like(values, 1 / values.shape[-1])
    return np.divide(values, totals, out=uniform, where=totals > 0)


def row_average(values, fallback):
    count = np.isfinite(values).sum(axis=1)
    return np.divide(np.nansum(values, axis=1), count, out=fallback.copy(), where=count > 0)


def annual_features(year):
    columns = [f"DC_{y}" for y in range(max(2010, year - 5), year)]
    previous = annual_cases[columns].to_numpy(float)
    zeros = np.zeros(barangay_count)
    mean5 = row_average(previous, zeros)
    mean3 = row_average(previous[:, -3:], mean5)
    missing = ~np.isfinite(previous[:, -1])
    last = np.where(missing, mean5, previous[:, -1])
    residents = zeros
    if year >= 2017:
        census = "pop2020" if year >= 2022 else "pop2015"
        residents = population[census].to_numpy(float)
    incidence = np.divide(last * 1e5, residents, out=zeros.copy(), where=residents > 0)
    return dict(
        annual_last=last, annual_mean3=mean3, annual_mean5=mean5,
        annual_last_missing=missing, annual_share=normalize(last),
        annual_share3=normalize(mean3), population=residents, pop_available=residents > 0,
        area=area, density=residents / area, annual_incidence=incidence,
        neighbor_annual_incidence=weights @ incidence, neighbor_annual_cases=weights @ last,
        neighbor_count=(weights > 0).sum(axis=1),
    )


@lru_cache(None)
def prior(year):
    """Combine completed-year seasonal patterns with recent annual shares."""
    features = annual_features(year)
    end = min((year - FIRST_YEAR) * WEEKS, len(local_cases))
    start = max(0, end - 3 * WEEKS)
    past = np.where(known[start:end], local_cases[start:end], 0)
    past = past.reshape(-1, WEEKS, barangay_count)
    shares = normalize(0.5 * normalize(past).mean(axis=0) + 0.5 * features["annual_share3"])
    return features, end, past, shares


def design(origin, mode, history=city_cases, local_history=None):
    """Build six horizon-major feature blocks. Origin is the last observed week."""
    annual, completed_end, past, shares = prior(FIRST_YEAR + (origin + 1) // WEEKS)

    def local_at(index):
        if index < 0:
            return np.full(barangay_count, np.nan)
        estimate = history[index] * shares[index % WEEKS]
        if local_history is not None and index < len(local_history):
            observed = local_history[index]
            return np.where(np.isfinite(observed), observed, estimate)
        if mode == "retrospective" and index < len(local_cases):
            return local_cases[index]
        if index < completed_end:
            return np.where(known[index], local_cases[index], estimate)
        return estimate

    recent = np.stack([local_at(origin - lag) for lag in range(12)])
    return feature_blocks(
        origin, history, recent, local_at(origin - WEEKS), annual, weights, past, shares
    )


def model(family):
    """Construct a fresh base estimator for a model family."""
    if family == "RF":
        from sklearn.ensemble import RandomForestRegressor

        return RandomForestRegressor(
            n_estimators=24, max_depth=10, min_samples_leaf=12, max_features=0.7,
            max_samples=0.3, n_jobs=4, random_state=42,
        )
    common = dict(
        n_estimators=85, learning_rate=0.06, subsample=0.8, colsample_bytree=0.85,
        reg_lambda=5, n_jobs=4, random_state=42,
    )
    if family == "XGB":
        from xgboost import XGBRegressor

        return XGBRegressor(**common, max_depth=5, tree_method="hist")
    if family == "LGBM":
        from lightgbm import LGBMRegressor

        return LGBMRegressor(
            **common, max_depth=6, num_leaves=28, min_child_samples=75,
            subsample_freq=1, verbosity=-1,
        )
    raise ValueError(f"Unknown model family {family!r}")


def predictions(origin, models, columns, history=city_cases, local_history=None,
                *, ensemble_members=FAMILIES, ensemble_name="ML_mean", mode="safe"):
    """Return a horizon-by-barangay matrix per estimator, ensemble, and baseline."""
    features, latest, shares = design(origin, mode, history, local_history)
    matrix = features[columns].to_numpy()
    values = {
        name: np.maximum(0, estimator.predict(matrix)).reshape(HORIZON, barangay_count)
        for name, estimator in models.items()
    }
    targets = origin + np.arange(1, HORIZON + 1)
    values[ensemble_name] = np.mean([values[key] for key in ensemble_members], axis=0)
    values["local_persistence"] = np.tile(latest, (HORIZON, 1))
    values["seasonal_naive"] = local_cases[targets - WEEKS]
    values["city_persist_seasonal_share"] = history[origin] * shares[targets % WEEKS]
    return values


def forecast(origin, models, columns, history, selected, out, local_history=None, *, output_dir=FORECASTS):
    values = predictions(origin, models, columns, history, local_history)
    rows = []
    for method, estimates in values.items():
        for horizon, counts in enumerate(estimates, start=1):
            target = origin + horizon
            rows.append(geography.assign(
                method=method, selected=method == selected, year=FIRST_YEAR + target // WEEKS,
                week=target % WEEKS + 1, horizon=horizon, expected_cases=counts,
            ))
    results = pd.concat(rows, ignore_index=True)
    city = results.groupby(
        ["method", "selected", "year", "week", "horizon"], as_index=False
    ).expected_cases.sum()
    city["actual_upri"] = city.week.map(external_cases).where(city.year == 2023)
    city["abs_error"] = abs(city.expected_cases - city.actual_upri)
    output_dir.mkdir(parents=True, exist_ok=True)
    results.to_csv(output_dir / f"{out}_all_models.csv", index=False)
    results.loc[results.selected].to_csv(output_dir / f"{out}_barangay.csv", index=False)
    city.to_csv(output_dir / f"{out}_city.csv", index=False)
    return city


# Earlier notebooks can still call the historical rolling-origin evaluation.
def fit(mode, cut):
    frames, targets, masks = [], [], []
    for origin in range(WEEKS, cut - HORIZON + 1, 3):
        features, _, _ = design(origin, mode)
        window = slice(origin + 1, origin + 1 + HORIZON)
        frames.append(features)
        targets.append(local_cases[window].ravel())
        masks.append(known[window].ravel())
    matrix = pd.concat(frames, ignore_index=True)
    keep = np.concatenate(masks)
    inputs, target = matrix.to_numpy()[keep], np.concatenate(targets)[keep]
    return {name: model(name).fit(inputs, target) for name in FAMILIES}, list(matrix)


def pred(o, mode, mods, cols, history=city_cases, local_history=None):
    return predictions(o, mods, cols, history, local_history, mode=mode)


def evaluate(mode, split, mods, cols, y0, y1):
    """Evaluate overlapping six-week forecasts and one full-year allocation."""
    records, annual_records = [], []
    for year in range(y0, y1 + 1):
        start = (year - FIRST_YEAR) * WEEKS
        last_origin = start + WEEKS - HORIZON - 1
        block_origins = set(range(start - 1, last_origin + 1, HORIZON)) | {last_origin}
        annual_totals, counted = {}, set()
        for origin in range(start - 1, last_origin + 1):
            values = pred(origin, mode, mods, cols)
            for horizon in range(1, HORIZON + 1):
                target = origin + horizon
                mask = known[target]
                for method, estimates in values.items():
                    counts = estimates[horizon - 1]
                    actual = local_cases[target, mask]
                    error = counts[mask] - actual
                    records.append(dict(
                        protocol=mode, split=split, method=method, origin=origin, year=year,
                        week=target % WEEKS + 1, horizon=horizon, actual_city=city_cases[target],
                        pred_city=counts.sum(), local_abs_sum=abs(error).sum(),
                        local_sq_sum=(error ** 2).sum(), n_local=mask.sum(),
                        imputed_actual_sum=actual.sum(),
                    ))
                    if origin in block_origins and target not in counted:
                        annual_totals.setdefault(method, np.zeros(barangay_count))
                        annual_totals[method] += counts
                if origin in block_origins:
                    counted.add(target)
        assert len(counted) == WEEKS
        actual = annual_cases[f"DC_{year}"].to_numpy(float)
        mask = np.isfinite(actual)
        actual = actual[mask]
        for method, counts in annual_totals.items():
            conditional = normalize(counts[mask]) * actual.sum()
            annual_records.append(dict(
                protocol=mode, split=split, method=method, year=year, n=mask.sum(),
                annual_raw_MAE=abs(counts[mask] - actual).mean(),
                annual_conditional_MAE=abs(conditional - actual).mean(),
                annual_total_forecast=counts.sum(), observed_known_total=actual.sum(),
            ))
    return records, annual_records


def metrics(records):
    """Score rolling-origin records, where every origin has a full six-week window."""
    from evaluate_split import score

    scores = score(records.assign(block_length=HORIZON)).rename(columns={"n_full_windows": "n_origins"})
    groups = records.groupby(["protocol", "split", "method"], as_index=False)
    sums = groups[["local_sq_sum", "local_abs_sum", "n_local", "imputed_actual_sum"]].sum()
    scores["local_imputed_RMSE"] = np.sqrt(sums.local_sq_sum / sums.n_local)
    scores["local_imputed_WAPE"] = 100 * sums.local_abs_sum / sums.imputed_actual_sum
    scores[["surge_recall", "surge_precision"]] = scores[["surge_recall", "surge_precision"]].fillna(0)
    return scores[[
        "protocol", "split", "method", "n_origins", "local_imputed_MAE", "local_imputed_RMSE",
        "local_imputed_WAPE", "city_MAE", "city_RMSE", "city_WAPE", "city_6week_total_MAE",
        "city_peak_MAE", "surge_recall", "surge_precision", "tp", "fp", "fn",
    ]]


def run():
    """Reproduce the older rolling-origin experiment in a separate output directory."""
    import json

    import joblib

    output = ROOT / "outputs" / "rolling_origin"
    output.mkdir(parents=True, exist_ok=True)
    weekly_records, annual_records = [], []
    for mode in ("safe", "retrospective"):
        for split, cutoff, first, last in (("validation", 363, 2019, 2020), ("test", 467, 2021, 2022)):
            models, columns = fit(mode, cutoff)
            weekly, annual = evaluate(mode, split, models, columns, first, last)
            weekly_records.extend(weekly)
            annual_records.extend(annual)
    backtest = pd.DataFrame(weekly_records)
    scores = metrics(backtest)
    scores.to_csv(output / "metrics.csv", index=False)
    backtest.to_csv(output / "weekly_backtest.csv", index=False)
    pd.DataFrame(annual_records).to_csv(output / "annual_metrics.csv", index=False)
    validation = scores.query("protocol == 'safe' and split == 'validation'")
    candidates = validation[validation.method.isin([*FAMILIES, "ML_mean"])]
    selected = candidates.sort_values(["city_6week_total_MAE", "local_imputed_MAE"]).iloc[0].method
    selection = dict(
        selected_ml=selected, local_mae_best_ml=candidates.sort_values("local_imputed_MAE").iloc[0].method,
        best_including_baselines=validation.sort_values("city_6week_total_MAE").iloc[0].method,
        criteria="safe validation six-week city cumulative MAE; local imputed MAE secondary",
        train_through=2022, horizon=HORIZON,
    )
    (output / "selection.json").write_text(json.dumps(selection, indent=2) + "\n")
    models, columns = fit("safe", len(city_cases) - 1)
    joblib.dump(dict(models=models, columns=columns, selection=selection), output / "models.joblib", compress=3)
    for prefix, history in [
        ("2023_w01_06", city_cases),
        ("2023_w07_12_updated", np.r_[city_cases, external_cases.iloc[:HORIZON]]),
    ]:
        forecast(len(history) - 1, models, columns, history, selected, prefix, output_dir=output)


if __name__ == "__main__":
    from evaluate_split import main

    main()
