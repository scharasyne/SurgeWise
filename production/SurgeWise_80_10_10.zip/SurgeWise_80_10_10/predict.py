"""Forecast six weeks with the saved models and optional 2023 observations."""

import argparse
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from engine import (
    FAMILIES, FORECASTS, HORIZON, MODELS, WEEKS, city_cases, codes, forecast,
    known, local_cases,
)


def load_updates(path, local_path):
    if path is None:
        if local_path is not None:
            raise ValueError("--local-updates requires --updates")
        return city_cases, None

    updates = pd.read_csv(path).sort_values(["year", "week"])
    count = len(updates)
    if (count > WEEKS - HORIZON or not updates.year.eq(2023).all()
            or not np.array_equal(updates.week, np.arange(1, count + 1))):
        raise ValueError("City updates must cover consecutive 2023 weeks starting at 1, up to week 46")
    counts = updates.city_cases.to_numpy(float)
    if not np.isfinite(counts).all() or (counts < 0).any():
        raise ValueError("City counts must be finite and nonnegative")
    history = np.r_[city_cases, counts]
    if local_path is None:
        return history, None

    local = pd.read_csv(local_path)
    if not local.year.eq(2023).all() or not local.week.isin(updates.week).all():
        raise ValueError("Local updates must match the supplied city weeks")
    if not local.barangay_code.isin(codes).all() or local.duplicated(["week", "barangay_code"]).any():
        raise ValueError("Each local update needs a known barangay code and a unique week/code pair")
    counts = local.cases.to_numpy(float)
    if not np.isfinite(counts).all() or (counts < 0).any():
        raise ValueError("Local counts must be finite and nonnegative")
    observed = np.full((count, len(codes)), np.nan)
    observed[local.week.to_numpy(int) - 1, pd.Index(codes).get_indexer(local.barangay_code)] = counts
    return history, np.vstack([np.where(known, local_cases, np.nan), observed])


def write_scenario(prefix, start, duration, multiplier, ramp):
    barangays = pd.read_csv(FORECASTS / f"{prefix}_barangay.csv")
    elapsed = barangays.horizon - start + 1
    active = elapsed.between(1, duration)
    increase = (multiplier - 1) * (elapsed / duration if ramp else 1)
    barangays["scenario_multiplier"] = np.where(active, 1 + increase, 1)
    barangays["scenario_expected_cases"] = barangays.expected_cases * barangays.scenario_multiplier
    barangays.to_csv(FORECASTS / f"{prefix}_scenario_barangay.csv", index=False)
    city = barangays.groupby(["year", "week", "horizon"], as_index=False)[
        ["expected_cases", "scenario_expected_cases"]
    ].sum()
    city.to_csv(FORECASTS / f"{prefix}_scenario_city.csv", index=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", choices=[*FAMILIES, "ML_mean"])
    parser.add_argument("--updates", type=Path, help="City CSV with year, week, city_cases")
    parser.add_argument("--local-updates", type=Path, help="Local CSV with year, week, barangay_code, cases")
    parser.add_argument("--out", default="prediction", help="Filename prefix in outputs/forecasts/")
    parser.add_argument("--multiplier", type=float, default=1)
    parser.add_argument("--start", type=int, default=1)
    parser.add_argument("--duration", type=int, default=HORIZON)
    parser.add_argument("--ramp", action="store_true")
    args = parser.parse_args()
    if not np.isfinite(args.multiplier) or args.multiplier < 1:
        parser.error("--multiplier must be finite and at least 1")
    if not 1 <= args.start <= HORIZON or not 1 <= args.duration <= HORIZON - args.start + 1:
        parser.error("The scenario must fit within forecast weeks 1 through 6")
    if not args.out or Path(args.out).name != args.out:
        parser.error("--out must be a filename prefix")

    try:
        history, local_history = load_updates(args.updates, args.local_updates)
    except (OSError, ValueError, KeyError) as error:
        parser.error(str(error))
    try:
        bundle = joblib.load(MODELS / "models.joblib")
    except ModuleNotFoundError as error:
        parser.exit(1, f"Loading the saved models requires {error.name}. "
                       "Install the packages in requirements.txt.\n")
    method = args.model or bundle["selection"]["selected_ml"]
    forecast(len(history) - 1, bundle["models"], bundle["columns"], history, method, args.out, local_history)
    write_scenario(args.out, args.start, args.duration, args.multiplier, args.ramp)
    print(f"Saved {method} forecast with {len(history) - len(city_cases)} city updates to {FORECASTS}")


if __name__ == "__main__":
    main()
