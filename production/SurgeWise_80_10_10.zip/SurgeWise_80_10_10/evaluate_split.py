"""Train, select, and evaluate models with blocked and chronological holdouts."""

import json

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

from engine import (
    EVALUATION, FAMILIES, FIRST_YEAR, HORIZON, MODELS, WEEKS, city_cases,
    design, external_cases, forecast, known, local_cases, model, predictions,
)

SEED = 42
TRAIN_END = (2021 - FIRST_YEAR) * WEEKS - 1
RANK_BY = ["city_6week_total_MAE", "local_imputed_MAE"]
CONFIGS = {
    "RF_shallow": dict(max_depth=6, min_samples_leaf=30, n_estimators=32),
    "RF_original": {},
    "RF_deeper": dict(max_depth=14, min_samples_leaf=8, n_estimators=24),
    "XGB_shallow": dict(max_depth=3, n_estimators=100, learning_rate=0.04, min_child_weight=15),
    "XGB_original": {},
    "XGB_regularized": dict(max_depth=4, n_estimators=85, learning_rate=0.05,
                            reg_lambda=15, min_child_weight=20),
    "LGBM_shallow": dict(max_depth=4, num_leaves=12, n_estimators=100,
                         learning_rate=0.04, min_child_samples=120),
    "LGBM_original": {},
    "LGBM_regularized": dict(max_depth=5, num_leaves=20, n_estimators=85,
                             learning_rate=0.05, reg_lambda=15, min_child_samples=150),
}
ORIGINALS = [f"{family}_original" for family in FAMILIES]
ENSEMBLE = "ML_mean_original"


def make_splits():
    """Assign whole holdout blocks, keeping each 52-week year intact at its edges."""
    blocks = [
        ((year - FIRST_YEAR) * WEEKS + offset, min(HORIZON, WEEKS - offset))
        for year in (2021, 2022) for offset in range(0, WEEKS, HORIZON)
    ]
    rng = np.random.default_rng(SEED)
    full = [i for i, (_, length) in enumerate(blocks) if length == HORIZON]
    short = [i for i, (_, length) in enumerate(blocks) if length < HORIZON]
    test_ids = set(rng.choice(full, 8, replace=False)) | set(rng.choice(short, 1, replace=False))
    splits = {
        "random_blocked": {
            "validation": [block for i, block in enumerate(blocks) if i not in test_ids],
            "test": [block for i, block in enumerate(blocks) if i in test_ids],
        },
        "chronological": {"validation": blocks[:9], "test": blocks[9:]},
    }
    index = np.arange(len(city_cases))
    assignment = pd.DataFrame(dict(index=index, year=FIRST_YEAR + index // WEEKS, week=index % WEEKS + 1))
    for protocol, groups in splits.items():
        assignment[protocol] = np.where(index < WEEKS, "warmup", "train")
        for group, intervals in groups.items():
            for start, length in intervals:
                assignment.loc[start:start + length - 1, protocol] = group
        assert assignment[protocol].value_counts().to_dict() == {
            "train": 416, "warmup": 52, "validation": 52, "test": 52,
        }
    return assignment, splits


def build_train(cut):
    """Assemble known labels up to and including the last eligible target week."""
    last_origin = cut - HORIZON
    origins = sorted(set(range(WEEKS - 1, last_origin + 1, 3)) | {last_origin})
    frames, targets, masks = [], [], []
    for origin in origins:
        features, _, _ = design(origin, "safe")
        window = slice(origin + 1, origin + 1 + HORIZON)
        frames.append(features)
        targets.append(local_cases[window].ravel())
        masks.append(known[window].ravel())
    keep = np.concatenate(masks)
    matrix = pd.concat(frames, ignore_index=True)
    return matrix.to_numpy()[keep], np.concatenate(targets)[keep], list(matrix)


def fit_candidates(variants, cutoff):
    matrix, targets, columns = build_train(cutoff)
    fitted = {}
    for name, variant in variants.items():
        estimator = model(variant.split("_")[0]).set_params(**CONFIGS[variant])
        fitted[name] = estimator.fit(matrix, targets)
        print(f"Fitted {variant} through week index {cutoff}", flush=True)
    return fitted, columns


def evaluate(models, columns, blocks, protocol, split):
    records = []
    for start, length in blocks:
        origin = start - 1
        estimates = predictions(origin, models, columns, ensemble_members=ORIGINALS, ensemble_name=ENSEMBLE)
        for method, values in estimates.items():
            for offset, counts in enumerate(values[:length]):
                target = start + offset
                mask = known[target]
                actual = local_cases[target, mask]
                error = counts[mask] - actual
                records.append(dict(
                    protocol=protocol, split=split, method=method, origin=origin, target_index=target,
                    year=FIRST_YEAR + target // WEEKS, week=target % WEEKS + 1, horizon=offset + 1,
                    block_length=length, actual_city=city_cases[target], pred_city=counts.sum(),
                    local_abs_sum=abs(error).sum(), local_sq_sum=(error ** 2).sum(),
                    n_local=mask.sum(), imputed_actual_sum=actual.sum(),
                ))
    return pd.DataFrame(records)


def score(results):
    """Score individual weeks and use full windows for cumulative and peak metrics."""
    rows = []
    for (protocol, split, method), group in results.groupby(["protocol", "split", "method"]):
        error = group.pred_city - group.actual_city
        windows = group[group.block_length == HORIZON].groupby("origin")[["actual_city", "pred_city"]]
        totals, peaks = windows.sum(), windows.max()
        previous = np.array([city_cases[o - HORIZON + 1:o + 1].sum() for o in totals.index])
        observed = totals.actual_city.to_numpy() >= 1.25 * previous
        alerted = totals.pred_city.to_numpy() >= 1.25 * previous
        tp = int((observed & alerted).sum())
        fp = int((~observed & alerted).sum())
        fn = int((observed & ~alerted).sum())
        rows.append(dict(
            protocol=protocol, split=split, method=method, n_weeks=len(group),
            n_full_windows=len(totals), local_n=group.n_local.sum(),
            local_imputed_MAE=group.local_abs_sum.sum() / group.n_local.sum(),
            city_MAE=abs(error).mean(), city_RMSE=np.sqrt((error ** 2).mean()),
            city_WAPE=100 * abs(error).sum() / group.actual_city.sum(),
            city_6week_total_MAE=abs(totals.pred_city - totals.actual_city).mean(),
            city_peak_MAE=abs(peaks.pred_city - peaks.actual_city).mean(),
            surge_recall=tp / (tp + fn) if tp + fn else np.nan,
            surge_precision=tp / (tp + fp) if tp + fp else np.nan, tp=tp, fp=fp, fn=fn,
        ))
    return pd.DataFrame(rows)


def select_models(validation):
    picks = {}
    for protocol, rows in validation.groupby("protocol"):
        ranked = rows.sort_values(RANK_BY)
        candidates = ranked[ranked.method.isin([*CONFIGS, ENSEMBLE])]
        picks[protocol] = dict(selected_ml=candidates.method.iloc[0], best_including_baselines=ranked.method.iloc[0])

    winner = picks["random_blocked"]["selected_ml"]
    ranked = validation[validation.protocol == "random_blocked"].sort_values(RANK_BY)
    variants = {
        family: ranked[ranked.method.str.startswith(family + "_")].method.iloc[0]
        for family in FAMILIES
    }
    if winner == ENSEMBLE:
        variants = dict(zip(FAMILIES, ORIGINALS))
    return dict(
        seed=SEED, criteria="Validation six-week city total MAE; local imputed MAE tie-break; test not used to tune",
        splits=picks, train_weeks=416, validation_weeks=52, test_weeks=52, warmup_weeks=52,
        selected_ml="ML_mean" if winner == ENSEMBLE else winner.split("_")[0],
        family_configs=variants, selected_variant=winner, train_through=2022, horizon=HORIZON,
    )


@threadpool_limits.wrap(limits=4)
def main():
    EVALUATION.mkdir(parents=True, exist_ok=True)
    MODELS.mkdir(parents=True, exist_ok=True)
    assignment, splits = make_splits()
    assignment.to_csv(EVALUATION / "split_assignment.csv", index=False)
    models, columns = fit_candidates({name: name for name in CONFIGS}, TRAIN_END)

    def evaluate_split(name):
        return pd.concat([
            evaluate(models, columns, groups[name], protocol, name)
            for protocol, groups in splits.items()
        ], ignore_index=True)

    validation = evaluate_split("validation")
    validation_scores = score(validation)
    validation_scores.to_csv(EVALUATION / "validation_metrics.csv", index=False)
    selection = select_models(validation_scores)
    results = pd.concat([validation, evaluate_split("test")], ignore_index=True)
    results.to_csv(EVALUATION / "weekly_backtest.csv", index=False)
    scores = score(results)
    scores.to_csv(EVALUATION / "metrics.csv", index=False)
    print(scores.round(3).to_string(index=False))

    final, columns = fit_candidates(selection["family_configs"], len(city_cases) - 1)
    bundle = dict(models=final, columns=columns, selection=selection)
    joblib.dump(bundle, MODELS / "models.joblib", compress=3)
    (MODELS / "selection.json").write_text(json.dumps(selection, indent=2) + "\n")
    for prefix, history in [
        ("2023_w01_06", city_cases),
        ("2023_w07_12_updated", np.r_[city_cases, external_cases.iloc[:HORIZON]]),
    ]:
        forecast(len(history) - 1, final, columns, history, selection["selected_ml"], prefix)


if __name__ == "__main__":
    main()
