"""Checks for map rows, unassigned cases and barangay chart history."""

import json
import unittest

from production.surgewise.api import application


def request(query):
    status = []
    result = application(
        {"PATH_INFO": "/gp-history", "REQUEST_METHOD": "GET", "QUERY_STRING": query},
        lambda code, headers: status.append(code),
    )
    return status[0], json.loads(b"".join(result))


class HistoryTest(unittest.TestCase):
    def test_maps_include_city_residual(self):
        status, result = request("year=2017")
        self.assertEqual(status, "200 OK")
        self.assertEqual(len(result["barangays"]), 142 * 52)
        totals = [0.0] * 52
        for row in result["barangays"]:
            self.assertNotEqual(row["barangay_code"], "UNASSIGNED")
            totals[row["week"] - 1] += row["gp_expected_cases"]
        self.assertEqual(len(result["city"]), 52)
        self.assertAlmostEqual(sum(row["unassigned_expected_cases"] for row in result["city"]), 3)
        for row, total in zip(result["city"], totals):
            self.assertAlmostEqual(total + row["unassigned_expected_cases"], row["observed_city_week_cases"])

    def test_barangay_series(self):
        status, result = request("barangay_code=PH1307404001")
        self.assertEqual(status, "200 OK")
        self.assertEqual(len(result["barangays"]), 572)
        first = result["barangays"][0]
        self.assertEqual((first["year"], first["week"], first["barangay"]), (2012, 1, "Alicia"))
        self.assertAlmostEqual(first["gp_expected_cases"], 0.5874418470)

    def test_historical_dates_only(self):
        status, _ = request("year=2023")
        self.assertEqual(status, "400 Bad Request")
