"""Check the deployable model against both historical forecast exports."""

import csv
import unittest
from pathlib import Path

import numpy as np

from production.surgewise.predictor import predict

ROOT = Path(__file__).resolve().parents[1]


class ProductionForecastTest(unittest.TestCase):
    def test_selected_forecasts(self):
        with (ROOT / "examples/updates_example.csv").open() as stream:
            updates = [{key: int(value) for key, value in row.items()} for row in csv.DictReader(stream)]

        for prefix, observations in [("2023_w01_06", []), ("2023_w07_12_updated", updates)]:
            with self.subTest(prefix=prefix):
                result = predict(city_updates=observations)
                actual = result["barangays"]
                with (ROOT / "outputs/forecasts" / f"{prefix}_barangay.csv").open() as stream:
                    expected = list(csv.DictReader(stream))
                self.assertEqual(len(actual), 852)
                self.assertEqual(
                    [(row["barangay_code"], row["week"]) for row in actual],
                    [(row["barangay_code"], int(row["week"])) for row in expected],
                )
                np.testing.assert_allclose(
                    [row["expected_cases"] for row in actual],
                    [float(row["expected_cases"]) for row in expected],
                    rtol=1e-12, atol=1e-12,
                )
