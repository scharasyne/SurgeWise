"""Exercise selectable horizons and scenario dates through the web entry point."""

import io
import json
import unittest

from production.surgewise.api import application


def post(**payload):
    body = json.dumps(payload).encode()
    status = []
    result = application({
        "PATH_INFO": "/predict", "REQUEST_METHOD": "POST", "CONTENT_TYPE": "application/json",
        "CONTENT_LENGTH": str(len(body)), "wsgi.input": io.BytesIO(body),
    }, lambda code, headers: status.append(code))
    return int(status[0][:3]), json.loads(b"".join(result))


class HorizonTests(unittest.TestCase):
    def test_each_horizon_matches_original_predictions(self):
        _, baseline = post()
        for weeks in range(1, 7):
            with self.subTest(weeks=weeks):
                status, result = post(weeks_ahead=weeks)
                self.assertEqual(status, 200)
                self.assertEqual(result["as_of"], {"year": 2022, "week": 52})
                self.assertEqual(result["weeks_ahead"], weeks)
                self.assertEqual(result["city"], baseline["city"][:weeks])
                self.assertEqual(result["barangays"], baseline["barangays"][:142 * weeks])

    def test_recent_window_matches_full_history_across_new_year(self):
        # Deterministic fixtures exercise the calendar and lags across year boundaries.
        updates = [
            {"year": 2023 + i // 52, "week": 1 + i % 52, "city_cases": 30 + (i * 7) % 53}
            for i in range(206)
        ]
        local = [
            {"year": u["year"], "week": u["week"], "barangay_code": "PH1307404001", "cases": 6}
            for u in updates[-53::4]
        ]
        options = dict(local_updates=local, weeks_ahead=4, multiplier=2, start=2, ramp=True)
        status, full = post(city_updates=updates, **options)
        self.assertEqual(status, 200)
        status, recent = post(city_updates=updates[-53:][::-1], **options)
        self.assertEqual(status, 200)
        self.assertEqual(recent, full)
        self.assertEqual(recent["as_of"], {"year": 2026, "week": 50})
        self.assertEqual([(r["year"], r["week"]) for r in recent["city"]],
                         [(2026, 51), (2026, 52), (2027, 1), (2027, 2)])
        for i, city in enumerate(recent["city"]):
            expected_factor = 1 + i / 3
            self.assertAlmostEqual(city["scenario_multiplier"], expected_factor)
            rows = recent["barangays"][i * 142:(i + 1) * 142]
            self.assertAlmostEqual(city["scenario_expected_cases"], sum(r["scenario_expected_cases"] for r in rows))

    def test_invalid_windows(self):
        for value in (0, 7, True, 2.5):
            self.assertEqual(post(weeks_ahead=value)[0], 400)
        self.assertEqual(post(weeks_ahead=2, duration=3)[0], 400)
        one = {"year": 2026, "week": 3, "city_cases": 50}
        self.assertEqual(post(city_updates=[one])[0], 400)
        self.assertEqual(post(city_updates=[one, one])[0], 400)
        observations = [{"year": 2023, "week": w, "city_cases": 20} for w in (1, 3)]
        self.assertEqual(post(city_updates=observations)[0], 400)
